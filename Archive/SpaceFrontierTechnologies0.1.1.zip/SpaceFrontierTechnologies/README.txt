This mod is definitely not done yet. I am new to modding a 3d game so i am still learning.  If you want to help me
dm me on discord (MEGA SLIME#9647).  Again this is completly new and I am fine with any critisism
here is the forum: https://forum.kerbalspaceprogram.com/index.php?/topic/194804-19-space-frontier-technologiessftlooking-for-testers/
